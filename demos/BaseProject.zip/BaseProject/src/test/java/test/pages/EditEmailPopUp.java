package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.ts.commons.Page;

class EditEmailPopUp extends Page{

	private WebDriver driver ;
	private WebElement destinyField;
	private WebElement textAreaTo;
	private WebElement ccSubButton;
	private WebElement elementCc;
	private WebElement elementSubject;
	private WebElement send;
	
	 public EditEmailPopUp(WebDriver driver) 
	{ 
		 this.driver = driver;
	} 
	  
	 public EditEmailPopUp sendEmail(String to, String cc, String subject, String text)
	 {		 
		 destinyField = driver.findElement(By.xpath("//div//div[text()='Destinatarios']"));
		 if( destinyField.isDisplayed() )
		 {
			 destinyField.click();
		 }
 
		 
		 textAreaTo = driver.findElement(By.xpath("//form//table//textarea[preceding-sibling::input[@class = 'wA']]"));
		 textAreaTo.sendKeys(to);
		 
		 ccSubButton = driver.findElement(By.xpath("//span[text()='Cc']"));
		 elementCc = driver.findElement(By.xpath("//textarea[@name='cc']"));
		 ccSubButton.click();
		 elementCc.sendKeys(cc);
		 
		 elementSubject = driver.findElement(By.xpath("//form//input[@name='subjectbox']"));
		 elementSubject.sendKeys(subject);
		 
		 send = driver.findElement(By.xpath("//div[text()='Enviar']"));
		 send.click();
		 
		 return this;
	 }
	
	@Override
	public EditEmailPopUp and() {
		return this;
	}

	@Override
	public EditEmailPopUp then() {
		return this;
	}

	public WebDriver getDriver() {
		return this.driver;
	}

}
