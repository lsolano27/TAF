package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ts.commons.Page;

public class Gmail extends Page{

	@FindBy(xpath = ".//*[@id=':hf']/div/div")
	private WebElement editBtn;
	
	@FindBy(id = "gbqfq")
	private WebElement searchField;
	
	@FindBy(id = "gbqfb")
	private WebElement searchButton;
	
	@FindBy(id = ":2i")
	private WebElement configurationButton;
	
	@FindBy(id = ":33")
	private WebElement selectButton;
	
	@FindBy(xpath = ".//*[@id=':5']/div/div[1]/div[1]/div/div/div[4]/div")
	private WebElement refreshButton;
	
	@FindBy(id = ":36")
	private WebElement moreButton;
	
	private WebDriver driver ;
	
	 public Gmail(WebDriver driver) 
	{ 
		 this.driver = driver;
	} 
	 
	 public Gmail searchInInbox(String text)
	 {
		 searchField.sendKeys(text);
		 searchButton.click();
		 return this;
	 }
	 
	 public Gmail sendEmail(String to, String cc, String subject, String text)
	 {
		 editBtn.click();
		 		 
		 EditEmailPopUp editEmailPopUp = new EditEmailPopUp(driver);
		 editEmailPopUp.sendEmail(to, cc, subject, text);
		 
		 return this;
	 }
	
	@Override
	public Gmail and() {
		return this;
	}

	@Override
	public Gmail then() {
		return this;
	}

	public WebDriver getDriver() {
		return this.driver;
	}

}
