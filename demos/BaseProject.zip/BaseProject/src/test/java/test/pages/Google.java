package test.pages; 

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import test.pages.gmail.ServiceLogin;
import test.validator.GoogleValidator;

import com.ts.commons.generator.Page;
import com.ts.commons.generator.PoWebElement;

public class Google extends Page {

	/* 
	* Don't delete or change this method, or the object will be generated again.
	*/ 
	public PoWebElement[] getPredifinedWebElements()
	{
		return new PoWebElement[] {new PoWebElement("id","gbqfq"), new PoWebElement("id","gbqfb"), new PoWebElement("id","gbqfba"), new PoWebElement("id","gbqfbb"), new PoWebElement("xpath",".//*[@id='pocs0']/a[1]"), new PoWebElement("xpath",".//*[@id='viewport']/a[1]"), new PoWebElement("xpath",".//*[@id='gb']/div[1]/div[1]/div[1]/div[1]/a[1]"), new PoWebElement("xpath",".//*[@id='gb']/div[1]/div[1]/div[1]/div[2]/a[1]"), new PoWebElement("xpath",".//*[@id='gb']/div[1]/div[1]/div[1]/div[3]/a[1]"), new PoWebElement("xpath",".//*[@id='gbwa']/div[1]/a[1]"), new PoWebElement("id","gb119"), new PoWebElement("id","gb1"), new PoWebElement("id","gb36"), new PoWebElement("id","gb8"), new PoWebElement("id","gb78"), new PoWebElement("id","gb5"), new PoWebElement("id","gb23"), new PoWebElement("id","gb25"), new PoWebElement("id","gb24"), new PoWebElement("xpath",".//*[@id='gbwa']/div[2]/a[1]"), new PoWebElement("id","gb51"), new PoWebElement("id","gb10"), new PoWebElement("id","gb212"), new PoWebElement("id","gb6"), new PoWebElement("id","gb30"), new PoWebElement("id","gb31"), new PoWebElement("xpath",".//*[@id='gbwa']/div[2]/a[2]"), new PoWebElement("id","gb_70"), new PoWebElement("xpath",".//*[@id='gbq1']/div[1]/a[1]"), new PoWebElement("xpath",".//*[@id='pmolnk']/a[1]"), new PoWebElement("xpath",".//*[@id='fsr']/a[1]"), new PoWebElement("id","fsettl"), new PoWebElement("xpath",".//*[@id='fsett']/a[1]"), new PoWebElement("xpath",".//*[@id='advsl']/a[1]"), new PoWebElement("xpath",".//*[@id='fsett']/a[2]"), new PoWebElement("xpath",".//*[@id='fsett']/a[3]"), new PoWebElement("id","fblqf"), new PoWebElement("xpath",".//*[@id='fsr']/a[2]"), new PoWebElement("xpath",".//*[@id='fsl']/a[1]"), new PoWebElement("xpath",".//*[@id='fsl']/a[2]"), new PoWebElement("xpath",".//*[@id='fsl']/a[3]")};
	}
	
	private WebDriver driver ;
	private GoogleValidator validator = new GoogleValidator(this);
	
	 public Google(WebDriver driver) 
	{ 
		 super(driver); 
		 this.driver = driver;
	} 

	@FindBy(id = "gbqfq")
	private WebElement input;
	
	@FindBy(id = "gbqfba")
	private WebElement buscarconGoogle;

	@FindBy(xpath = ".//*[@id='gb']/div[1]/div[1]/div[1]/div[1]/a[1]")
	private WebElement aTu;

	@FindBy(xpath = ".//*[@id='gb']/div[1]/div[1]/div[1]/div[2]/a[1]")
	private WebElement aGmail;

	@FindBy(xpath = ".//*[@id='gb']/div[1]/div[1]/div[1]/div[3]/a[1]")
	private WebElement aImagenes;

	@FindBy(xpath = ".//*[@id='gbwa']/div[1]/a[1]")
	private WebElement aAplicaciones;

	@FindBy(xpath = ".//*[@id='pmolnk']/a[1]")
	private WebElement aInstalaGoogleChrome;

	@FindBy(xpath = ".//*[@id='fsr']/a[1]")
	private WebElement aNuevoPrivacidadYCondiciones;


	@FindBy(xpath = ".//*[@id='fsr']/a[2]")
	private WebElement aGoogleCoCr;

	@FindBy(xpath = ".//*[@id='fsl']/a[1]")
	private WebElement aPublicidad;

	@FindBy(xpath = ".//*[@id='fsl']/a[2]")
	private WebElement aEmpresa;

	@FindBy(xpath = ".//*[@id='fsl']/a[3]")
	private WebElement aAcercaDe;
	
	public Google search(String text)
	{
		input.sendKeys(text);
		validator.suggestionsAreFireUpAfterSearchSomething(this).Validate();
		buscarconGoogle = driver.findElement(By.id("gbqfb"));
		buscarconGoogle.click();
		return this;
	}
	
	public ServiceLogin goToGmailPage()
	{
		aGmail.click();
		driver.findElement(By.id("gmail-sign-in")).click();
		return PageFactory.initElements(driver, ServiceLogin.class);
	}
	
	public WebDriver getDriver()
	{
		return driver;
	}

	public Google and() 
	{
		return this;
	}

	public Google then() 
	{
		return this;
	}

	
}
