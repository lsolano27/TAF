package test.pages;

import org.openqa.selenium.support.PageFactory;

import com.ts.commons.FirefoxDriver;

public class UI {
	
	public static Google goToGooglePage()
	{
		FirefoxDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/");
		return PageFactory.initElements(driver, Google.class);
	}

}
