package test.pages.gmail;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import test.pages.Gmail;

import com.ts.commons.Page;

public class ServiceLogin extends Page{

	@FindBy(id = "Email")
	private WebElement mail;
	
	@FindBy(id = "Passwd")
	private WebElement password;
	
	@FindBy(id = "signIn")
	private WebElement signIn;
	
	private WebDriver driver;
	
	 public ServiceLogin(WebDriver driver) 
	{ 
		 this.driver = driver;
	} 
	
	public Gmail signIn(String email, String password)
	{
		mail.sendKeys(email);
		this.password.sendKeys(password);
		this.signIn.click();
		return PageFactory.initElements(driver, Gmail.class);
	}

	@Override
	public ServiceLogin and() {
		return this;
	}

	@Override
	public ServiceLogin then() {
		return this;
	}
}
