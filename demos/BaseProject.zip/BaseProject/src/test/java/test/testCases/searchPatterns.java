package test.testCases;

import org.testng.annotations.Test;
import test.pages.UI;
import test.validator.GoogleValidator;
import com.ts.commons.Page;
import com.ts.commons.TestCaseUtil;

public class searchPatterns extends TestCaseUtil {
	
	@Test
	public void searchText()
	{
		Page currentPage;
		using
		(
			currentPage= UI.
			goToGooglePage().
			search("Costa Rica")
		).
		check
		(
			new GoogleValidator(currentPage).
			validatedisplayedLinksContainsTheWord("Wikipedia")
		);
	}
	
	@Test
	void searchFormula()
	{
		Page currentPage;
		using
		(
			currentPage= UI.
			goToGooglePage().
			search("1+1")
		).
		check
		(
				new GoogleValidator(currentPage).
				validateResult("2")
		);
	}

}
