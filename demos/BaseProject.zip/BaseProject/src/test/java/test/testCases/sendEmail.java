package test.testCases;

import org.testng.annotations.Test;

import test.pages.UI;
import test.validator.GmailValidator;

import com.ts.commons.Page;
import com.ts.commons.TestCaseUtil;

public class sendEmail extends TestCaseUtil {
	
	@Test
	public void searchText()
	{
		Page currentPage;
		using
		(
			currentPage= UI.
			goToGooglePage().
			and().
			goToGmailPage().
			then().
			signIn("yourmail", "password").
			then().
			searchInInbox("promotional").
			sendEmail("yourmail", "", "Prototional", "Hello Word")
		).
		check
		(
			new GmailValidator(currentPage).
			googleIconsIsDisplayed()
		);
	}

}
