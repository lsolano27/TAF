package test.testCases;

import org.testng.annotations.Test;

import test.pages.UI;
import test.validator.GmailValidator;

import com.ts.commons.Page;
import com.ts.commons.TestCaseUtil;

public class sendEmail extends TestCaseUtil {
	
	@Test
	public void searchText()
	{
		Page currentPage;
		using
		(
			currentPage= UI.
			goToGooglePage().
			and().
			goToGmailPage().
			then().
			signIn("cguillen@testingsoft.com", "cguillen123").
			then().
			searchInInbox("promotional").
			sendEmail("cguillen@testingsoft.com", "", "Prototional", "Hello Word")
		).
		check
		(
			new GmailValidator(currentPage).
			googleIconsIsDisplayed()
		);
	}

}
