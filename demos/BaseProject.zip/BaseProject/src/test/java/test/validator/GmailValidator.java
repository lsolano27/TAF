package test.validator; 

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import test.pages.Gmail;

import com.ts.commons.Page;
import com.ts.commons.Validator;

public class GmailValidator {

	private Gmail gmail;
	
	public GmailValidator(Page page)
	{
		this.gmail = (Gmail)page;
	}
	
	public Validator googleIconsIsDisplayed()
	{
		return new Validator() {
			
			@Override
			public void Validate() {
				WebElement icon =  gmail.getDriver().findElement(By.xpath(".//*[@id='gbq1']/div/a"));
				Assert.assertTrue(icon.isDisplayed());				
			}
		};
	}	
}
