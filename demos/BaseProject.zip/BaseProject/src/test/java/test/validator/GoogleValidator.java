package test.validator; 

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import test.pages.Google;

import com.ts.commons.FirefoxDriver;
import com.ts.commons.Page;
import com.ts.commons.Validator;

public class GoogleValidator {

	private Google google;
	
	public GoogleValidator(Page page)
	{
		google = (Google) page;
	}
	
	public Validator suggestionsAreFireUpAfterSearchSomething(Page page)
	{
		return new Validator() {
			
			@Override
			public void Validate() {
				WebElement suggestions =  google.getDriver().findElement(By.xpath(".//*[@id='gsr']/table"));
				((FirefoxDriver)google.getDriver()).waitToElementBeVisible(suggestions);
				Assert.assertTrue(suggestions.isDisplayed());				
			}
		};
	}
	
	public Validator validateResult( String expectedValue) 
	{
		final String expected = expectedValue;
		
		return new Validator()
		{
			
			@Override
			public void Validate() 
			{
				WebElement suggestions =  google.getDriver().findElement(By.xpath(".//*[@id='cwos']"));
				Assert.assertEquals(suggestions.getText(), expected);				
			}
		};
	}
	
	public Validator validatedisplayedLinksContainsTheWord(String expectedValue) 
	{
		final String expected = expectedValue;
		
		return new Validator() 
			{
					
				@Override
				public void Validate() 
				{
					List<WebElement> links =  google.getDriver().findElements(By.xpath(".//*[@id='rso']//h3//a[contains(.,'"+expected+"')]"));
					Assert.assertTrue(links.size() > 0);				
				}
			};
	}

	
}
